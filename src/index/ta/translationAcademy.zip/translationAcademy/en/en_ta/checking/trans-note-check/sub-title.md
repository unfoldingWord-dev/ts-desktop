How do I do a translationNotes check?
