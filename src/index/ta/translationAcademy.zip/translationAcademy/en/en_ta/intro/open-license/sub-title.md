What freedoms do users have with unfoldingWord® content?
